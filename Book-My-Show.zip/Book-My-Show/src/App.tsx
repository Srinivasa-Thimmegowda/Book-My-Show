import React, { useEffect } from 'react';
import './App.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
  RouteComponentProps,
} from "react-router-dom";
import MovieDetails from './movie-details/MovieDetails';
import MovieSearch from './movie-search/MovieSearch';



function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route
            path="/movie-details"
            render={(props: RouteComponentProps) => (
              <MovieDetails routerProps={props} />
            )}
          />

          <Route
            path="/movie-search"
            render={(props: RouteComponentProps) => (
              <MovieSearch routerProps={props} />
            )}
          />

          <Redirect from="/" to="/movie-search" />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
