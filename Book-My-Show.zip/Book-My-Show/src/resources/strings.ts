const strings = {
    enter_movie_name_to_search: "Enter movie name to search:",
    search: "Search",
    title: "Title:",
    year: "Year:",
    poster: "Poster:",
    please_select_anyone_theater: "Please Select Any one Theatre:",
    please_select_movie_timing: "Please Select Movie Timing",
    please_select_movie_seats: "Please Select Movie Seats",
    ok: "Ok",
    confirm: "Confirm"
}

export default strings;