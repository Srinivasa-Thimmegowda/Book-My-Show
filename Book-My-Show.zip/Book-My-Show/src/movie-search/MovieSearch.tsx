import React, { useState } from 'react'
import axios from 'axios';
import MovieCard from '../movie-card/MovieCard';
import { RouteComponentProps } from 'react-router-dom';
import strings from '../resources/strings';



export interface IMovieSearchProps {
    routerProps: RouteComponentProps
}

function MovieSearch(props: IMovieSearchProps) {

    const [movieName, setMovieName] = useState("");
    const [moviesList, setMoviesList] = useState([]);

    async function searchMoviesByName(movieName: string) {
        const response = await axios.get(`http://www.omdbapi.com/?s=${movieName}&apikey=e6b1e426`);
        setMoviesList(response.data.Search);
    }

    return (
        <div>
            <div>
                <span>{strings.enter_movie_name_to_search}</span>
                <input
                    type="text"
                    value={movieName}
                    onChange={(event: any) => {
                        setMovieName(event.target.value)
                    }}
                />
                <button
                    onClick={() => {
                        movieName.length > 0 && searchMoviesByName(movieName)
                    }}
                >
                    {strings.search}
                </button>
            </div>


            <div className="d-flex flex-wrap">
                {moviesList?.map((movie: any, index: number) => {
                    return <div key={`${movie}-${index}`} className="col-4 pt-5">
                        <MovieCard Title={movie.Title} Year={movie.Year} Poster={movie.Poster} routerProps={props.routerProps} />
                    </div>
                })}
            </div>

        </div>
    )
}

export default MovieSearch;