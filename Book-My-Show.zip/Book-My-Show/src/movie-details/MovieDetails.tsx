import { Dialog } from '@material-ui/core';
import Button from '@material-ui/core/Button/Button';
import React from 'react';
import { useState } from 'react';
import { RouteComponentProps } from 'react-router-dom';
import strings from '../resources/strings';
import './MovieDetails.css'

export interface IMovieDetailsProps {
    routerProps: RouteComponentProps;
}

function MovieDetails(props: IMovieDetailsProps) {
    const [theatreList] = useState(['Gopalan Mall', 'Orion Mall', 'Multiplex Cinema']);
    const [selectedTheater, setSelectedTheater] = useState('');
    const [movieTimeList] = useState(['10am-1pm', '2pm-5pm', '6pm-9pm']);
    const [selectedMovieTime, setSelectedMovieTime] = useState('');
    const [movieSeatNumberList] = useState([{ seat: 1, isSelected: false }, { seat: 2, isSelected: false }, { seat: 3, isSelected: false }, { seat: 4, isSelected: false }, { seat: 5, isSelected: false }]);
    const [selectedMovieSeatList, setSelectedMovieSeatList] = useState([{ seat: 1, isSelected: false }, { seat: 2, isSelected: false }, { seat: 3, isSelected: false }, { seat: 4, isSelected: false }, { seat: 5, isSelected: false }]);
    const [showConfirmationAlert, setShowConfirmationAlert] = useState(false);


    const getSelectedMovieSeatCount = () => {
        let selectedMovieSeatCount = 0;
        selectedMovieSeatList?.forEach((movieSeat: any) => {
            if (movieSeat.isSelected) {
                selectedMovieSeatCount += 1;
            }
        })
        return selectedMovieSeatCount;
    }

    return (
        <div>
            <div className="col-12 px-0 pt-4">
                <span className="p-4">{strings.please_select_anyone_theater}</span>
                <div className="d-flex p-4">
                    {theatreList?.map((theatre: any, index: number) => {
                        return <div key={index} className={`p-4 border cursor-pointer ${selectedTheater === theatre && 'movieDetails-selected-color'}`}
                            onClick={() => {
                                setSelectedTheater(theatre)
                            }}
                        >
                            <span>{theatre}</span>
                        </div>
                    })}
                </div>
            </div>

            <div className="col-12 px-0 pt-4">
                <span className="p-4">{strings.please_select_movie_timing}</span>
                <div className="d-flex p-4">
                    {movieTimeList?.map((movieTime: any, index: number) => {
                        return <div key={index} className={`p-4 border cursor-pointer ${selectedMovieTime === movieTime && 'movieDetails-selected-color'}`}
                            onClick={() => {
                                setSelectedMovieTime(movieTime)
                            }}
                        >
                            <span>{movieTime}</span>
                        </div>
                    })}
                </div>
            </div>


            <div className="col-12 px-0 pt-4">
                <span className="p-4">{strings.please_select_movie_seats}</span>
                <div className="d-flex p-4">
                    {movieSeatNumberList?.map((movieSeat: any, index: number) => {

                        return <div
                            key={index}
                            className={`p-4 border cursor-pointer   ${selectedMovieSeatList[movieSeat.seat - 1].isSelected && 'movieDetails-selected-color'}`}
                            onClick={() => {
                                let selectedMovieSeatNumbers: any = [...selectedMovieSeatList]
                                if (movieSeat.seat - 1 === index) {
                                    selectedMovieSeatNumbers[movieSeat.seat - 1].isSelected = true;
                                }
                                setSelectedMovieSeatList(selectedMovieSeatNumbers)
                            }}
                        >
                            <span>{movieSeat.seat}</span>
                        </div>
                    })}
                </div>
            </div>

            <div className="p-4">
                <Button
                    className="movieDetails-selected-color text-capitalize"
                    onClick={() => {
                        setShowConfirmationAlert(true);
                    }}
                >
                    {strings.confirm}
                </Button>
            </div>

            <Dialog
                open={showConfirmationAlert}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <div className="p-4 row mx-0 d-flex justify-content-center flex-column">
                    <span>{`You have selected ${getSelectedMovieSeatCount()} seats`}</span>
                    <Button
                        className="mt-4 movieDetails-selected-color"
                        onClick={() => {
                            props.routerProps.history.push("/movie-search")
                        }}
                    >
                        {strings.ok}
                    </Button>
                </div>
            </Dialog>

        </div >
    )
}

export default MovieDetails;