import React from 'react';
import strings from '../resources/strings';
import './MovieCard.css';

export interface IMovieCardProps {
    Title: string;
    Year: string;
    Poster: string;
    routerProps: any;
}

function MovieCard(props: IMovieCardProps) {
    return (
        <div
            className=" p-3 d-flex flex-column col-12 px-0 cursor-pointer movieCard"
            onClick={() => {
                props.routerProps.history.push('/movie-details')
            }}
        >

            <div className="col-12 px-0">
                <span className="col-4">{strings.title}</span>
                <span className="col-8">{props.Title}</span>
            </div>

            <div className="col-12 px-0">
                <span className="col-4">{strings.year}</span>
                <span className="col-8">{props.Year}</span>
            </div>


            <div className="col-12 px-0">
                <span className="col-4">{strings.poster}</span>
                <img className="col-8" style={{ objectFit: "contain", height: "150px" }} src={props.Poster} alt="movie-poster" />
            </div>
        </div>
    )
}

export default MovieCard;